import{bv as e,r as t}from"./entry.23c03e9b.js";const o=e("type",()=>({type:t({type:""})}));export{o as u};
